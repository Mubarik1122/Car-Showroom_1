﻿Partial Class CustomerDataSet
    Partial Class CustomerDataTable

    End Class

End Class
